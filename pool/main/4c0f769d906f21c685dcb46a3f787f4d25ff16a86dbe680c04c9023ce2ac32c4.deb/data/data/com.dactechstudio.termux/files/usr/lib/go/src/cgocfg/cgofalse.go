//go:build !cgo
    
package cgocfg
    
const Enabled = false
