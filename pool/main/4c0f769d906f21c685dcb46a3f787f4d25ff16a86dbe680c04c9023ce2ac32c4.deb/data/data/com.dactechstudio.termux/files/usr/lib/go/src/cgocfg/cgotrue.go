//go:build cgo
    
package cgocfg
    
const Enabled = true
