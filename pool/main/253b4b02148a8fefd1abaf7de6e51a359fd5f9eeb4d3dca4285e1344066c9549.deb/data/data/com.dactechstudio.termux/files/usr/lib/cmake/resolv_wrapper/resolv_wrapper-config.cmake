set(RESOLV_WRAPPER_LIBRARY /data/data/com.dactechstudio.termux/files/usr/lib/libresolv_wrapper.so)
