##
## This script is sourced by /data/data/com.dactechstudio.termux/files/usr/bin/login before executing shell.
##
