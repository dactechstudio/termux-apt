if [ ! -e /data/data/com.dactechstudio.termux/files/home/.config/termux/termux.properties ] && [ ! -e /data/data/com.dactechstudio.termux/files/home/.termux/termux.properties ]; then
	mkdir -p /data/data/com.dactechstudio.termux/files/home/.config/termux/
	cp /data/data/com.dactechstudio.termux/files/usr/share/examples/termux/termux.properties /data/data/com.dactechstudio.termux/files/home/.config/termux/termux.properties
fi
