export TMUX_TMPDIR=/data/data/com.dactechstudio.termux/files/usr/var/run
